#####################################################################################
# Making a map using R #
# Making a map esesntially involves three steps --- getting a shape file for map, 
#		getting the data, and plotting. As an example, we will make a map of sex ratio
#		(defined as = 100*(# of females/# of males)) in states of India. But the ideas
#		are quite general. 
# Much of what you would see below has been learnt from:
# (a) http://www.kevjohnson.org/making-maps-in-r/ for a general introduction to map
#		making in R
# (b) https://www.nceas.ucsb.edu/~frazier/RSpatialGuides/colorPaletteCheatsheet.pdf 
#		for an introduction to colors in R
# See also:
# https://www.nceas.ucsb.edu/~frazier/RSpatialGuides/ggmap/ggmapCheatsheet.pdf
#		for an introduction to using Google maps in making maps using 
#		using the R package ggmap
#####################################################################################

# Use ?functionname to see help on any unfamiliar functions.
# If not already installed, use install.packages("packagename") to first install 
# a package before loading with library command.

library(raster) # to get map shape file
library(ggplot2) # for plotting and miscellaneuous things
library(ggmap) # for plotting
library(plyr) # for merging datasets
library(scales) # to get nice looking legends

# Get a shape file of states of India

india.shape <- getData("GADM", country = "India", level = 1)

# Plot to see how the map looks (may take a while)

# plot(india.shape)

# Look at the names of states (only 35 states and union territories)

# > india.shape$NAME_1
 # [1] "Andaman and Nicobar"    "Andhra Pradesh"         "Arunachal Pradesh"     
 # [4] "Assam"                  "Bihar"                  "Chandigarh"            
 # [7] "Chhattisgarh"           "Dadra and Nagar Haveli" "Daman and Diu"         
# [10] "Delhi"                  "Goa"                    "Gujarat"               
# [13] "Haryana"                "Himachal Pradesh"       "Jammu and Kashmir"     
# [16] "Jharkhand"              "Karnataka"              "Kerala"                
# [19] "Lakshadweep"            "Madhya Pradesh"         "Maharashtra"           
# [22] "Manipur"                "Meghalaya"              "Mizoram"               
# [25] "Nagaland"               "Orissa"                 "Puducherry"            
# [28] "Punjab"                 "Rajasthan"              "Sikkim"                
# [31] "Tamil Nadu"             "Tripura"                "Uttar Pradesh"         
# [34] "Uttaranchal"            "West Bengal"           
# > 

# To merge population data to the shape file, convert the shape file into a dataframe

india.df <- fortify(india.shape)

# > str(india.df)
# 'data.frame':	524966 obs. of  7 variables:
 # $ long : num  92.9 92.9 92.9 92.9 92.9 ...
 # $ lat  : num  12.9 12.9 12.9 12.9 12.9 ...
 # $ order: int  1 2 3 4 5 6 7 8 9 10 ...
 # $ hole : logi  FALSE FALSE FALSE FALSE FALSE FALSE ...
 # $ piece: Factor w/ 212 levels "1","2","3","4",..: 1 1 1 1 1 1 1 1 1 1 ...
 # $ group: Factor w/ 803 levels "1.1","1.2","1.3",..: 1 1 1 1 1 1 1 1 1 1 ...
 # $ id   : chr  "1" "1" "1" "1" ...
# > 

# Issue: the dataframe does not have state names, only id's
# Add the state names to the data frame

india.df$id <- as.numeric(india.df$id)
state.names <- data.frame(id = 1:length(india.shape$NAME_1), state = india.shape$NAME_1)
india.df <- join(india.df, state.names, by = "id", type = "inner")

# > str(india.df)
# 'data.frame':	524966 obs. of  8 variables:
 # $ long : num  92.9 92.9 92.9 92.9 92.9 ...
 # $ lat  : num  12.9 12.9 12.9 12.9 12.9 ...
 # $ order: int  1 2 3 4 5 6 7 8 9 10 ...
 # $ hole : logi  FALSE FALSE FALSE FALSE FALSE FALSE ...
 # $ piece: Factor w/ 212 levels "1","2","3","4",..: 1 1 1 1 1 1 1 1 1 1 ...
 # $ group: Factor w/ 803 levels "1.1","1.2","1.3",..: 1 1 1 1 1 1 1 1 1 1 ...
 # $ id   : num  1 1 1 1 1 1 1 1 1 1 ...
 # $ state: Factor w/ 35 levels "Andaman and Nicobar",..: 1 1 1 1 1 1 1 1 1 1 ...
# > 

# Get the sex ratio population data based on 2011 census
# source: http://www.census2011.co.in/sexratio.php
# notes:
# (a) you can get data on other variables as well, and
# (b) after getting the datafile, make sure the states have the same spellings
# as in the shape file.

india.dat <- read.table("india_sexratio.csv", header = T, sep = ",")

# > str(india.dat)
# 'data.frame':	36 obs. of  2 variables:
 # $ state   : Factor w/ 36 levels "Andaman and Nicobar",..: 19 28 32 2 7 24 23 27 25 11 ...
 # $ sexratio: int  1084 1037 996 993 991 989 985 979 976 973 ...
# >  

# > levels(india.dat$state)
 # [1] "Andaman and Nicobar"    "Andhra Pradesh"         "Arunachal Pradesh"     
 # [4] "Assam"                  "Bihar"                  "Chandigarh"            
 # [7] "Chhattisgarh"           "Dadra and Nagar Haveli" "Daman and Diu"         
# [10] "Delhi"                  "Goa"                    "Gujarat"               
# [13] "Haryana"                "Himachal Pradesh"       "India"                 
# [16] "Jammu and Kashmir"      "Jharkhand"              "Karnataka"             
# [19] "Kerala"                 "Lakshadweep"            "Madhya Pradesh"        
# [22] "Maharashtra"            "Manipur"                "Meghalaya"             
# [25] "Mizoram"                "Nagaland"               "Orissa"                
# [28] "Puducherry"             "Punjab"                 "Rajasthan"             
# [31] "Sikkim"                 "Tamil Nadu"             "Tripura"               
# [34] "Uttar Pradesh"          "Uttarakhand"            "West Bengal"           
# > 

# Note: state variable has 36 levels --- 35 states and union territories + entire country


# Merge the shape data with the population data by state name

india.df <- join(india.df, india.dat, by = "state", type = "inner")

# > str(india.df)
# 'data.frame':	522037 obs. of  9 variables:
 # $ long    : num  92.9 92.9 92.9 92.9 92.9 ...
 # $ lat     : num  12.9 12.9 12.9 12.9 12.9 ...
 # $ order   : int  1 2 3 4 5 6 7 8 9 10 ...
 # $ hole    : logi  FALSE FALSE FALSE FALSE FALSE FALSE ...
 # $ piece   : Factor w/ 212 levels "1","2","3","4",..: 1 1 1 1 1 1 1 1 1 1 ...
 # $ group   : Factor w/ 803 levels "1.1","1.2","1.3",..: 1 1 1 1 1 1 1 1 1 1 ...
 # $ id      : num  1 1 1 1 1 1 1 1 1 1 ...
 # $ state   : Factor w/ 35 levels "Andaman and Nicobar",..: 1 1 1 1 1 1 1 1 1 1 ...
 # $ sexratio: int  876 876 876 876 876 876 876 876 876 876 ...
# > 

# plot of sex ratio

# > range(india.df$sexratio)
# [1]  618 1084
# > 

# Divide sex ratio into class intervals --- there will be one color for each interval
# provide only the upper limits of the intervals (the break points)
 
brks <- c(900, 925, 950, 975, 1000, 1100)

p <- ggplot() +
# with borders (slower)
	geom_polygon(data = india.df, aes(x = long, y = lat, group = group, fill = sexratio), 
		color = "black", size = 0.15) +
# without borders(faster)
# 	geom_polygon(data = india.df, aes(x = long, y = lat, group = group, fill = sexratio), 
#		color = "black", size = 0.25) +	
	scale_fill_distiller(palette = "Reds", breaks = brks, trans = "reverse") +
	theme_nothing(legend = TRUE) +
	labs(title = "Sex ratio of states in India", fill = "")	

# Note: we are using shades of red for plotting; trans = "reverse" option 
# Makes the shades go from dark to light as the sexratio increases, thus 
# ensuring that darkest red = worst case scenario.

# Save the map to a file to viewing (you can plot on the screen also, but it takes
# much longer that way)

ggsave(p, file = "india_sexratio_map.pdf")

##################################################################################
p <- ggplot() +
  geom_polygon(data = China.df, aes(x = long, y = lat, group = group, fill = GDP), 
               color = "black", size = 0.15) +
  scale_fill_distiller(palette = "Reds", breaks = brks, trans = "reverse") +
  theme_nothing(legend = TRUE) +
  labs(title = "2015 China GDP", fill = "") +
  coord_map()+geom_text(x=state.center$x, y=state.center$y,, aes(x = clong, y = clat, label = id, size = 0.2))



